# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["URLContextResultStep", "Result"]


class Result(BaseModel):
    """The result of the URL context."""

    status: Optional[Literal["success", "error", "paywall", "unsafe"]] = None
    """The status of the URL retrieval."""

    url: Optional[str] = None
    """The URL that was fetched."""


class URLContextResultStep(BaseModel):
    """URL context result step."""

    call_id: str
    """Required. ID to match the ID from the function call block."""

    result: List[Result]
    """Required. The results of the URL context."""

    type: Literal["url_context_result"]

    is_error: Optional[bool] = None
    """Whether the URL context resulted in an error."""

    signature: Optional[str] = None
    """A signature hash for backend validation."""
